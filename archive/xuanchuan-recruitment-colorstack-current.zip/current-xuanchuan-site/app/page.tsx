"use client";

import { useEffect, useState } from "react";

const groups = [
  { key: "摄影组", lead: "在现场按下快门，也把后来会想念的瞬间留下。", lines: ["记录大会、义卖与部门日常", "完成照片筛选、整理与后期", "让真实的表情成为集体记忆"], image: "/assets/team-photo.jpg" },
  { key: "平面设计组", lead: "从一张空白画布开始，把想法变成校园里真正出现的作品。", lines: ["设计海报、推送封面与活动物料", "建立清楚、有辨识度的视觉表达", "让创意从草稿完整走到落地"], image: "/assets/team-design.jpg" },
  { key: "公众号组", lead: "从一个标题开始，把信息理清，也把值得停留的故事说出去。", lines: ["负责推文写作、采访与校对", "完成公众号排版与后台运营", "让每一件值得知道的事被看见"], image: "/assets/team-wechat.jpg" },
];

const stories = [
  { tag: "鲜花义卖", title: "把春天和心意一起送出去", text: "从活动预热、视觉物料，到当天的拍摄与记录，我们让一场义卖有了完整的样子。", image: "/assets/flowers.jpg" },
  { tag: "初遇 PR", title: "第一次见面，故事从这里开始", text: "有人负责举起相机，有人开始讨论文案和排版，也有人只是先记住了彼此的名字。", image: "/assets/first-meet-group.jpg" },
  { tag: "汕尾出游", title: "工作之外，我们也认真一起生活", text: "海风、晚霞、合照和没有写进工作记录里的笑声，同样构成了宣传部。", image: "/assets/shanwei.jpg" },
];

function Reveal({children,className=""}:{children:React.ReactNode;className?:string}){return <div className={`reveal ${className}`}>{children}</div>}

export default function Home(){
  const [active,setActive]=useState(0);
  useEffect(()=>{const els=document.querySelectorAll(".reveal");const ob=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add("shown")),{threshold:.14});els.forEach(e=>ob.observe(e));return()=>ob.disconnect()},[]);
  const group=groups[active];
  return <main>
    <header className="site-nav">
      <a className="logo" href="#top"><span className="logo-glyph"><i/><i/><i/></span><b>PR</b><small>宣传部</small></a>
      <nav><a href="#about">关于我们</a><a href="#groups">三个分组</a><a href="#stories">作品与日常</a><a className="pill" href="#join">加入我们</a></nav>
    </header>

    <section className="hero" id="top">
      <img className="hero-photo" src="/assets/hero-first-meet.jpg" alt="宣传部成员合照"/>
      <div className="hero-copy"><Reveal><h1>让文字、设计<br/>和照片，把正在<br/>发生的事<span>留下来</span>。</h1><div className="hero-actions"><a className="solid" href="#groups">看看三个分组</a><a href="#about">认识宣传部</a></div></Reveal></div>
      <div className="support"><span>我们用这些方式记录</span><div className="support-track"><b>推文</b><b>摄影</b><b>海报</b><b>排版</b><b>活动</b><b>推文</b><b>摄影</b></div></div>
    </section>

    <section className="about" id="about"><Reveal><p className="eyebrow">我们在做什么</p><h2>宣传部把散落在现场的<br/><em>文字、画面与情绪</em><br/>变成一件件看得见的事。</h2><a className="outline" href="#stories">继续了解</a></Reveal></section>

    <section className="groups" id="groups">
      <div className="group-left">
        <div className="tabs" role="tablist">{groups.map((g,i)=><button key={g.key} role="tab" aria-selected={active===i} onClick={()=>setActive(i)}>{g.key}</button>)}</div>
        <Reveal className="group-text"><p>{group.lead}</p>{group.lines.map(x=><p key={x}>{x}</p>)}</Reveal>
      </div>
      <div className="group-visual" key={group.key}><span className="arc teal">◠</span><img src={group.image} alt={`${group.key}工作与日常`}/><span className="arc orange">◠</span></div>
    </section>

    <section className="wall"><Reveal><h3>宣传部的频道里，<br/>每天都有人把想法变成作品。</h3></Reveal><div className="board"><aside><strong>PR 宣传部</strong><span>频道</span><b># 灵感与作品</b><b># 活动现场</b><b># 日常分享</b></aside><div className="messages"><h4>正在发生的事...</h4>{[
      ["摄影组","今天的照片已整理好，抓到好多很自然的瞬间。","/assets/team-photo.jpg"],
      ["平面设计组","招新主视觉出了新版本，欢迎来一起挑细节。","/assets/design-poster.jpg"],
      ["公众号组","推文初稿完成，标题还想再大胆一点。","/assets/team-wechat.jpg"],
      ["全体成员","下一次活动、下一张合照，等你一起出现。","/assets/meeting.jpg"]
    ].map(([n,t,img])=><article key={n}><img src={img}/><p><strong>{n}</strong><small>今天</small><br/>{t}</p></article>)}</div></div></section>

    <section className="stories" id="stories"><div className="news-band"><span>我们的作品与日常　我们的作品与日常　我们的作品与日常　我们的作品与日常</span></div><div className="story-grid">{stories.map((s,i)=><Reveal className="story" key={s.title}><img src={s.image} alt={s.title}/><small>{s.tag}</small><h3>{s.title}</h3><p>{s.text}</p><a href="#join">看看更多 <span>→</span></a></Reveal>)}</div></section>

    <section className="join" id="join"><img src="/assets/team-building.jpg" alt="宣传部团建合照"/><Reveal className="join-card"><small>下一页，等你来写</small><h2>加入宣传部，<br/>和我们一起<br/>留下故事。</h2><a href="#top">回到开头　↑</a></Reveal></section>
    <footer><a className="logo footer-logo" href="#top"><span className="logo-glyph"><i/><i/><i/></span><b>PR</b><small>宣传部</small></a><div><small>页面导航</small><a href="#about">关于我们</a><a href="#groups">三个分组</a><a href="#stories">作品与日常</a></div><div><small>深圳大学志愿者联合会</small><p>这里的文字、设计、照片与回忆，<br/>都来自认真生活过的我们。</p></div></footer>
  </main>
}
