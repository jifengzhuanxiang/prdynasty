const services = [
  {
    number: "01",
    title: "视觉设计",
    copy: "海报、推文头图与活动视觉，让每一次志愿行动拥有清晰、鲜明的表达。",
    className: "service-card service-pink",
  },
  {
    number: "02",
    title: "影像记录",
    copy: "用照片与视频留下真实现场，把一次活动变成值得反复翻看的共同记忆。",
    className: "service-card service-yellow",
  },
  {
    number: "03",
    title: "内容传播",
    copy: "从选题、文案到发布，以学生视角讲好志愿故事，让更多人看见并参与。",
    className: "service-card service-blue",
  },
];

const projects = [
  { type: "CAMPAIGN", title: "志愿招募季", note: "主视觉 · 推文 · 现场物料", color: "coral" },
  { type: "STORY", title: "志愿者故事", note: "人物采访 · 摄影 · 长图", color: "blue" },
  { type: "RECORD", title: "活动影像志", note: "纪实摄影 · 短视频", color: "violet" },
];

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="深大志联宣传部首页">
          <span className="brand-mark">PR</span>
          <span className="brand-name">深大志联宣传部</span>
        </a>
        <nav className="desktop-nav" aria-label="主导航">
          <a href="#about">关于我们</a>
          <a href="#work">我们在做</a>
          <a href="#projects">作品与现场</a>
          <a href="#join">加入 PR</a>
        </nav>
        <a className="header-cta" href="#join">
          认识我们 <span aria-hidden="true">↗</span>
        </a>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow"><span /> SHENZHEN UNIVERSITY VOLUNTEERS</p>
          <h1>
            让志愿，
            <br />
            <span>被看见。</span>
          </h1>
          <p className="hero-description">
            我们是深大志联宣传部 <strong>PR</strong>。用设计、影像与文字，
            记录行动，也让善意抵达更远的地方。
          </p>
          <div className="hero-actions">
            <a className="button button-dark" href="#projects">看看我们做了什么 <span>↘</span></a>
            <a className="text-link" href="#about">了解 PR <span>→</span></a>
          </div>
        </div>

        <div className="hero-art" aria-label="PR 创意工作台插画">
          <div className="sun-disc" />
          <div className="poster poster-back">
            <span>VOLUNTEER</span>
            <b>把热爱<br />做成回响</b>
            <small>SZU · 2026</small>
          </div>
          <div className="poster poster-front">
            <div className="poster-pr">PR</div>
            <p>DESIGN<br />STORY<br />IMPACT</p>
            <div className="poster-stamp">志愿<br />在场</div>
          </div>
          <div className="spark spark-one">✦</div>
          <div className="spark spark-two">✦</div>
          <div className="tape">MAKE IT VISIBLE</div>
        </div>
      </section>

      <div className="ticker" aria-hidden="true">
        <div>
          <span>DESIGN FOR GOOD</span><i>✦</i>
          <span>记录真实现场</span><i>✦</i>
          <span>MAKE VOLUNTEERING VISIBLE</span><i>✦</i>
          <span>让善意被看见</span><i>✦</i>
          <span>DESIGN FOR GOOD</span><i>✦</i>
          <span>记录真实现场</span><i>✦</i>
        </div>
      </div>

      <section className="about section-pad" id="about">
        <div className="section-label">WHAT WE DO <span>01</span></div>
        <div className="about-grid">
          <h2>宣传，不只是<br />“发一条推文”。</h2>
          <div>
            <p className="lead">
              我们把散落的想法变成一套完整表达：先找到值得说的故事，
              再选择最合适的视觉、文字与镜头。
            </p>
            <p>
              静态第一版暂以部门介绍和作品展示为主。真实项目、成员照片与招新信息，
              后续都可以由你们逐步替换，不会虚构部门履历。
            </p>
          </div>
        </div>

        <div className="service-grid" id="work">
          {services.map((service) => (
            <article className={service.className} key={service.title}>
              <div className="service-top">
                <span>{service.number}</span>
                <span className="service-icon" aria-hidden="true">↗</span>
              </div>
              <h3>{service.title}</h3>
              <p>{service.copy}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="projects section-pad" id="projects">
        <div className="projects-heading">
          <div>
            <div className="section-label">SELECTED WORK <span>02</span></div>
            <h2>作品，也是<br />我们的在场证明。</h2>
          </div>
          <p>这里先放三类示例栏目。等你们有真实海报、推文截图和活动照片后，可以直接替换卡片内容。</p>
        </div>

        <div className="project-list">
          {projects.map((project, index) => (
            <article className={`project-card project-${project.color}`} key={project.title}>
              <div className="project-index">0{index + 1}</div>
              <div className="project-visual">
                <div className="visual-tag">{project.type}</div>
                <div className="visual-type">{index === 0 ? "志愿" : index === 1 ? "STORY" : "ON SITE"}</div>
                <span className="visual-dot" />
              </div>
              <div className="project-info">
                <h3>{project.title}</h3>
                <p>{project.note}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="quote-section">
        <div className="quote-star">✦</div>
        <blockquote>
          “好的宣传不是替行动加上一层包装，<br />
          而是让行动本身的价值被准确地看见。”
        </blockquote>
        <p>— PR 的工作信念</p>
      </section>

      <section className="join section-pad" id="join">
        <div className="join-card">
          <div className="join-copy">
            <div className="section-label light">JOIN THE TEAM <span>03</span></div>
            <h2>下一次被看见的故事，<br />也许由你来讲。</h2>
            <p>
              对设计、摄影、剪辑、写作或新媒体感兴趣？欢迎认识 PR。
              招新时间与联系渠道将在确认后更新。
            </p>
            <a className="button button-light" href="mailto:replace-with-your-email@example.com">
              联系方式待更新 <span>↗</span>
            </a>
          </div>
          <div className="join-monogram" aria-hidden="true">
            <span>P</span><span>R</span>
            <div>PUBLIC<br />RELATIONS</div>
          </div>
        </div>
      </section>

      <footer>
        <div className="footer-brand"><span>PR</span> 深大志联宣传部</div>
        <p>深圳大学学生志愿服务宣传团队 · 静态网站第一版</p>
        <a href="#top">BACK TO TOP ↑</a>
      </footer>
    </main>
  );
}
