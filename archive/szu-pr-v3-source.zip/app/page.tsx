"use client";

import { useState } from "react";

const channels = {
  "今天在干嘛": [
    ["阿岚", "刚把昨晚活动的照片导出来。有人笑场的那张，我私心想放第一张。", "21:18"],
    ["摄影组", "相机借回来了。明天下午谁有空，一起去拍一点夏天？", "21:26"],
    ["PR 资料库", "「五月活动」新增 18 个被好好留下的瞬间。", "21:40"],
  ],
  "灵感乱撞": [
    ["设计组", "如果今年的招新不是一张海报，而是一封从 PR 寄出的邀请呢？", "14:06"],
    ["文案组", "想写一句不解释我们是谁，却让人愿意继续看下去的话。", "14:12"],
    ["匿名成员", "保留那朵剪歪的小花吧，不完美才像我们真的做过。", "14:18"],
  ],
  "周末出逃": [
    ["出游发起人", "周六四点集合。胶片机、扑克牌和好心情，缺一不可。", "10:02"],
    ["小林", "海边那张所有人都在笑的照片，申请进入年度精选。", "10:17"],
    ["PR 资料库", "一段没有工作群消息的下午，正在归档……", "10:31"],
  ],
} as const;

const stories = [
  { tag: "OUR DAYS", title: "一起出发的日子", text: "部门出游 · 地点与故事待补充", tone: "photo-one" },
  { tag: "OUR WORK", title: "把想法做成作品", text: "招新主题 · 视觉设计 · 幕后过程", tone: "photo-two" },
  { tag: "ON SITE", title: "我们在现场", text: "志愿活动 · 摄影记录 · 共同记忆", tone: "photo-three" },
];

export default function Home() {
  const [active, setActive] = useState<keyof typeof channels>("今天在干嘛");

  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top">
          <span className="brand-mark">PR</span>
          <span><b>深大志联宣传部</b><small>SZU VOLUNTEERS</small></span>
        </a>
        <nav>
          <a href="#story">我们的故事</a>
          <a href="#window">内部橱窗</a>
          <a href="#gallery">照片与作品</a>
        </nav>
        <div className="header-actions">
          <a className="login" href="#login">登录</a>
          <a className="meet" href="#story">认识我们 <span>↓</span></a>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="hero-photo placeholder-photo">
          <span className="photo-label">精选照片占位 · 16:10</span>
          <div className="frame-corner">PR / 001</div>
        </div>
        <div className="hero-copy">
          <p className="kicker">PUBLIC RELATIONS · SHENZHEN UNIVERSITY</p>
          <h1>这里收集<br />我们共同生活过的<br /><em>证据。</em></h1>
          <p className="intro">我们拍照、写字、做设计，也一起吃饭、出游、笑场。比起一份部门简介，这里更像一本还没写完的合志。</p>
          <a className="round-link" href="#story">翻开第一页 <span>↘</span></a>
          <span className="hero-count">SCROLL TO DISCOVER<br />01 — 04</span>
        </div>
      </section>

      <section className="statement" id="story">
        <p className="reveal">有些瞬间很小，</p>
        <p className="reveal delay-one">小到只是一阵风、一顿饭，</p>
        <p className="reveal delay-two"><em>和一群人恰好笑在一起。</em></p>
        <span>但后来回头看，组成我们的，偏偏就是这些。</span>
      </section>

      <section className="editorial">
        <div className="editorial-copy">
          <p className="section-no">02 / A STORY TO BEGIN</p>
          <h2>每一年，<br />我们都换一种方式，<br />邀请新的人走进来。</h2>
          <p>2023 — 2025 的主题一直在变，但想说的话没有变：欢迎你，来和我们一起，做点好看的东西，也经历一点值得记住的生活。真实照片、标题与故事将在这里逐年替换。</p>
          <a href="#gallery">翻看我们的片段 →</a>
        </div>
        <div className="story-stack">
          <div className="story-photo placeholder-photo"><span>年度招新主视觉占位</span></div>
          <div className="story-note"><b>2025</b><span>年度主题名称待补充</span><small>RECRUITMENT STORY</small></div>
        </div>
      </section>

      <section className="community" id="window">
        <div className="community-heading">
          <p className="section-no">03 / FROM THE INSIDE</p>
          <h2>偶尔，听听 PR 里面<br />正在发生什么。</h2>
          <p>未来这里会从内部区域挑选公开内容；现在展示的是交互与排版占位。</p>
        </div>
        <div className="forum-shell">
          <aside>
            <div className="forum-brand"><span>PR</span><b>内部回声</b></div>
            <small>公开橱窗</small>
            {(Object.keys(channels) as Array<keyof typeof channels>).map((name) => (
              <button key={name} className={active === name ? "active" : ""} onClick={() => setActive(name)}>
                <span>#</span>{name}
              </button>
            ))}
            <div className="internal-link">进入内部区域 <span>↗</span></div>
          </aside>
          <div className="chat-window">
            <div className="chat-top"><b># {active}</b><span>缓慢播放中　•••</span></div>
            <div className="chat-scroll">
              {[...channels[active], ...channels[active]].map((msg, index) => (
                <article className="message" key={`${msg[0]}-${index}`}>
                  <div className={`avatar avatar-${index % 3}`}>{msg[0].slice(0, 1)}</div>
                  <div><b>{msg[0]} <time>{msg[2]}</time></b><p>{msg[1]}</p></div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="gallery" id="gallery">
        <div className="gallery-head">
          <div><p className="section-no">04 / SELECTED MOMENTS</p><h2>一些照片，<br />和照片背后的我们。</h2></div>
          <p>这里未来放部门出游、活动现场，以及由宣传部完成的设计作品。所有内容均可逐项替换。</p>
        </div>
        <div className="story-grid">
          {stories.map((story, index) => (
            <article key={story.title}>
              <div className={`gallery-photo placeholder-photo ${story.tone}`}><span>精选照片 0{index + 1}</span></div>
              <p className="card-tag">{story.tag}</p>
              <h3>{story.title}</h3>
              <p>{story.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="login-panel" id="login">
        <p>PR MEMBERS ONLY</p>
        <h2>外面是我们的故事，<br />里面是故事发生的地方。</h2>
        <button type="button">成员登录 <span>↗</span></button>
        <small>静态版暂不接入真实账号系统</small>
      </section>

      <footer>
        <div className="footer-brand">PR</div>
        <div><b>深大志联宣传部</b><p>学生团队展示网站 · 内容持续更新</p></div>
        <a href="#top">回到顶部 ↑</a>
      </footer>
    </main>
  );
}
